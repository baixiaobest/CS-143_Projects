Baixiao Huang
504313981

I should have implemented all features in the demo site. The random browsing page is not
implemented. TA suggested in Piazza that browsing page can be implemented along with
the search feature, where user is allow to click Actor or Movie links for additional
information. I did what TA said as alternative to random browsing page.
Jquery and Javascript files are only used for adding multiple genres to Movie in ADD MOVIE
feature, where radio button for selecting genre is abandoned and more user friendly feature
is implemented.
