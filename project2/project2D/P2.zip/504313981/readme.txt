Baixiao Huang
504313981

Vector library is used for implementation. Vector gives
me more flexibility in dealing with memory data.